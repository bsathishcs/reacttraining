import React from "react";

class Home extends React.Component {
  render() {
    return (
      <div>
        <br />
        <br />
        <br />
        <br />
        <br />
        <h1 style={{ color: "coral" }}>Welcome to Employee Databases!</h1>
      </div>
    );
  }
}

export default Home;
