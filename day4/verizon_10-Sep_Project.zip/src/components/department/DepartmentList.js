import React from "react";

class DepartmentList extends React.Component {
  render() {
    return (
      <div>
        <h1>Departments</h1>
      </div>
    );
  }
}

export default DepartmentList;
